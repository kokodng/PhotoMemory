package com.example.adyu.photomemory.app;

public class AppValues {
    public static final int REGISTER_PARAMETER = 1;
    public static final String TAG = "xyzyx";
    public static final String INTERNAL_PRIVATE_MEMORY = "INTERNAL_PRIVATE_MEMORY";
    public static final String EXTERNAL_PRIVATE_MEMORY = "EXTERNAL_PRIVATE_MEMORY";
    public static final String EXTERNAL_PUBLIC_MEMORY = "EXTERNAL_PUBLIC_MEMORY";
}
